package Lamda_Expressions;

import java.util.ArrayList;

public class Q6_List {
public static void main(String[] args) {
	ArrayList<String> a=new ArrayList<>();
	a.add("Virat");
	a.add("Virat");
	a.add("Dhoni");
	a.add("Rishabh");
	a.add("Warner");
	a.add("Miller");
	a.add("Bravo");
	a.add("Pollard");
	a.add("Southee");
	a.add("Boult");
}
}
